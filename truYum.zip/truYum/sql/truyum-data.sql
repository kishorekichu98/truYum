CREATE DATABASE truyum;
USE truyum;

CREATE TABLE menu_item(
ID INT AUTO_INCREMENT PRIMARY KEY,
Name VARCHAR(50),
Price VARCHAR(10),
Active VARCHAR(10),
Date_of_Launch DATE,
Category VARCHAR(10),
Free_delivery VARCHAR(10)
);

ALTER TABLE menu_item MODIFY Price DECIMAL(10,2);
ALTER TABLE menu_item MODIFY Category VARCHAR(50);

CREATE TABLE users(
userId INT AUTO_INCREMENT PRIMARY KEY,
userName VARCHAR(50)
);

CREATE TABLE cart(
cartId INT AUTO_INCREMENT PRIMARY KEY,
userId INT,
ID INT,
CONSTRAINT Fk1 FOREIGN KEY (userId) REFERENCES users(userId),
CONSTRAINT Fk2 FOREIGN KEY (ID) REFERENCES menu_item(ID)
);
1.
INSERT INTO menu_item(Name,Price,Active,Date_of_Launch,Category,Free_delivery)
values("Sandwich","99.00","Yes","2017-03-15","Main course","Yes"),
("Burger","129.00","Yes","2017-12-23","Main course","No"),
("Pizza","149.00","Yes","2017-08-21","Main course","No"),
("French Fries","57.00","No","2017-07-02","Starters","Yes"),
("Chocolate Brownie","32.00","Yes","2022-11-02","Dessert","Yes");
 
 SELECT * FROM menu_item;
 
SELECT Name,CONCAT('Rs. ',Price) AS 'Price',Active,Date_of_Launch,Category,Free_delivery FROM menu_item;


2.
SELECT Name,concat('Rs. ',Price) AS 'Price',
Category,Free_delivery FROM menu_item
WHERE Active = 'Yes' AND Date_of_launch <= curdate();

3.
a.
SET @ID = 2;
SELECT Name,concat('Rs. ',Price) AS 'Price',Active,Date_of_Launch,Category,Free_delivery FROM menu_item WHERE ID = @ID;

b.
UPDATE menu_item
SET Price='135.00'
WHERE ID= @ID;

4. 
INSERT INTO users(userName)
VALUES('kishore'),('R');

INSERT INTO cart(userId,ID) values(2,3),(2,1),(2,4);

 5. 
 a.
SET @userId = 2;
 SELECT Name,CONCAT('Rs. ',Price) AS 'Price',Category,Free_delivery FROM menu_item m
 INNER JOIN cart c ON m.ID = c.ID
 INNER JOIN users u ON u.userId = c.userId
 WHERE u.userId = @userId;
 
 b.
 SET @userId = 2;
 SELECT SUM(Price) AS Totalprice FROM menu_item m 
 INNER JOIN cart c ON m.ID = c.ID
 INNER JOIN users u ON u.userId = c.userId
 WHERE u.userId = @userId;
 
  6.
 SET @userId = 2;
 SET @ID = 4;
 DELETE FROM cart 
 WHERE ID = @ID AND userId = @userId;
 

 
 
 


